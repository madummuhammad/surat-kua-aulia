<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Department;
use App\Models\Letter;
use App\Models\Sender;
use App\Models\PenerimaSurat;
use App\Models\Notification;

use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
class LetterController extends Controller
{

    public function index()
    {
        //
    }

    public function create()
    {
        $departments = Department::all();
        $senders = Sender::all();
        $receivers = PenerimaSurat::all();

        return view('pages.admin.letter.create',[
            'departments' => $departments,
            'senders' => $senders,
            'receivers' => $receivers,
        ]);
    }

    public function goToNotification(Request $request,$id)
    {
        Notification::where('id',$id)->update(['read_at'=>date('Y-m-d H:i:s')]);
        if($request->tipe_arsip=='surat'){            
            $letter=Letter::findOrFail($request->id_surat);
            if($letter->status=='Approve'){
                return redirect('admin/letter/surat/'.$request->id_surat);
            }

            if($letter->status=='pending'){
                return redirect('admin/letter/surat/'.$request->id_surat);
            }

            if($letter->status=='Not Approve'){
                return redirect('admin/letter/surat/'.$request->id_surat);
            }

            if($letter->status=='Request Update'){
                return redirect('admin/letter/'.$request->id_surat.'/edit');
            }
        } else {
            return redirect('admin/employee-archive/'.$request->id_surat.'/edit');
        }
    }

    public function store(Request $request)
    {
        if($request->letter_type=='Surat Masuk'){
            $validatedData = $request->validate([
                'letter_no' => [
                    'required',
                    Rule::unique('arsip_surat')->where(function ($query) use ($request) {
                        return $query->where('letter_type', 'Surat Masuk');
                    }),
                ],
                'letter_date' => 'required',
                'date_received' => 'required',
                'regarding' => 'required',
                'department_id' => 'required',
                'id_penerima_surat' => 'required',
                'letter_file' => 'required|mimes:pdf|file',
                'letter_type' => 'required',
            ]);
        } else {            
            $validatedData = $request->validate([
                   'letter_no' => [
                    'required',
                    Rule::unique('arsip_surat')->where(function ($query) use ($request) {
                        return $query->where('letter_type', 'Surat Keluar');
                    }),
                ],
                'letter_date' => 'required',
                'date_received' => 'required',
                'regarding' => 'required',
                'department_id' => 'required',
                'sender_id' => 'required',
                'letter_file' => 'required|mimes:pdf|file',
                'letter_type' => 'required',
            ]);
        }

        if($request->file('letter_file')){
            $validatedData['letter_file'] = $request->file('letter_file')->store('assets/letter-file');
        }

        $type='Surat Masuk';
        if ($validatedData['letter_type'] == 'Surat Masuk') {
            $redirect = 'surat-masuk';
        } else {
            $type='Surat Keluar';
            $redirect = 'surat-keluar';
        }

        $letter=Letter::create($validatedData);

        Notification::create([
            'keterangan'=>'Ada '.$type.' baru<br>Kode :'.$letter->letter_no.'<br> Keterangan: Surat baru dibuat oleh '.auth()->user()->name,
            'id_surat'=>$letter->id,
            'level'=>'manajer'
        ]);

        return redirect()
        ->route($redirect)
        ->with('success', 'Sukses! 1 Data Berhasil Disimpan');
    }

    public function approval_letter($id)
    {
        $komentar=request('komentar');
        $status=request('status');
        $letter=Letter::findOrFail($id);

        $type='Surat Masuk';
        if ($letter->letter_type == 'Surat Masuk') {
            $redirect = 'surat-masuk';
        } else {
            $redirect = 'surat-keluar';
            $type='Surat Keluar';
        }
        $letter->update(['status'=>$status]);

        if($status=='Approve'){            
            Notification::create([
                'keterangan'=>$type.' '.$status.'<br>Kode :'.$letter->letter_no,
                'id_surat'=>$letter->id,
                'level'=>'karyawan'
            ]);
        }

        if($status=='Request Update'){
            $letter->update(['komentar_request'=>$komentar]);
            Notification::create([
                'keterangan'=>$type.' '.$status.'<br>Kode :'.$letter->letter_no.'<br> Keterangan: '.$komentar,
                'id_surat'=>$letter->id,
                'level'=>'karyawan'
            ]);
        }

        if($status=='Not Approve'){
            $letter->update(['komentar_not_approve'=>$komentar]);
            Notification::create([
                'keterangan'=>$type.' '.$status.'<br>Kode :'.$letter->letter_no.'<br> Keterangan: '.$komentar,
                'id_surat'=>$letter->id,
                'level'=>'karyawan'
            ]);
        }
        return redirect()
        ->route($redirect)
        ->with('success', 'Sukses! 1 Data Berhasil '.$status);
    }

    public function incoming_mail()
    {
        if (request()->ajax()) {
            $query = Letter::with(['department', 'receiver'])->where('letter_type', 'Surat Masuk')->latest()->get();

            return Datatables::of($query)
            ->addColumn('action', function ($item) {
                $buttons = '<a class="btn btn-success btn-xs" href="' . route('detail-surat', $item->id) . '">
                <i class="fa fa-search-plus"></i> &nbsp; Detail
                </a>
                ';

                if (auth()->user()->level == 'karyawan') {
                    if($item->status=='pending' ||$item->status=='Request Update'){
                        $buttons .= '<a class="btn btn-primary btn-xs" href="' . route('letter.edit', $item->id) . '">
                        <i class="fas fa-edit"></i> &nbsp; Ubah
                        </a>
                        ';
                    }

                    if($item->status=='pending' ||$item->status=='Request Update'){
                        $buttons .= '<form action="' . route('letter.destroy', $item->id) . '" method="POST" onsubmit="return confirm(' . "'Anda akan menghapus item ini?'" . ')">
                        ' . method_field('delete') . csrf_field() . '
                        <button class="btn btn-danger btn-xs">
                        <i class="far fa-trash-alt"></i> &nbsp; Hapus
                        </button>
                        </form>';
                    }
                }

                if (auth()->user()->level == 'manajer') {
                    $buttons .= '<form action="' . route('letter.destroy', $item->id) . '" method="POST" onsubmit="return confirm(' . "'Anda akan menghapus item ini?'" . ')">
                    ' . method_field('delete') . csrf_field() . '
                    <button class="btn btn-danger btn-xs">
                    <i class="far fa-trash-alt"></i> &nbsp; Hapus
                    </button>
                    </form>';
                }

                if (auth()->user()->level == 'manajer') {
                    if($item->status=='pending'){
                        $buttons .= '
                        <form action="' . route('approval', $item->id) . '" method="POST" onsubmit="return confirm(' . "'Anda akan approve item ini?'" . ')">
                        ' . method_field('post') . csrf_field() . '
                        <input name="status" value="Approve"/ hidden>
                        <button class="btn btn-success btn-xs">
                        <i class="fas fa-check"></i> &nbsp; Approve
                        </button>
                        </form>
                        <form action="' . route('approval', $item->id) . '" method="POST" onsubmit="return submitFormReq()">
                        ' . method_field('post') . csrf_field() . '
                        <input name="status" value="Request Update" hidden>
                        <input id="commentInput" name="komentar" value="" hidden>
                        <button class="btn btn-warning btn-xs">
                        <i class="fas fa-exclamation"></i> &nbsp; Request
                        </button>
                        </form>
                        <script>
                        function submitFormReq() {
                            var comment = prompt("Anda akan request perubahan?");
                            if (comment === null) {
                                return false;
                            }

                            document.getElementById("commentInput").value = comment;
                            return true;
                        }
                        </script>
                        </form>
                        <form action="' . route('approval', $item->id) . '" method="POST" onsubmit="return submitForm()">
                        ' . method_field('post') . csrf_field() . '
                        <input name="status" value="Not Approve" hidden>
                        <input id="commentInputNot" name="komentar" value="" hidden>
                        <button class="btn btn-danger btn-xs">
                        <i class="fas fa-exclamation"></i> &nbsp; Not Approve
                        </button>
                        </form>
                        <script>
                        function submitForm() {
                            var comment = prompt("Anda akan Not Approve?");
                            if (comment === null) {
                                return false;
                            }

                            document.getElementById("commentInputNot").value = comment;
                            return true;
                        }
                        </script>
                        </form>';
                    }
                }

                return $buttons;
            })
->editColumn('post_status', function ($item) {
    return $item->post_status == 'Published' ? '<div class="badge bg-green-soft text-green">' . $item->post_status . '</div>' : '<div class="badge bg-gray-200 text-dark">' . $item->post_status . '</div>';
})
->addIndexColumn()
->removeColumn('id')
->rawColumns(['action', 'post_status'])
->make();
}

return view('pages.admin.letter.incoming');

}

public function outgoing_mail()
{
    if (request()->ajax()) {
        $query = Letter::with(['department','sender'])->where('letter_type', 'Surat Keluar')->latest()->get();

        return Datatables::of($query)
        ->addColumn('action', function ($item) {
            $buttons = '<a class="btn btn-success btn-xs" href="' . route('detail-surat', $item->id) . '">
            <i class="fa fa-search-plus"></i> &nbsp; Detail
            </a>
            ';

            if (auth()->user()->level == 'karyawan') {
                if($item->status=='pending' ||$item->status=='Request Update'){
                    $buttons .= '<a class="btn btn-primary btn-xs" href="' . route('letter.edit', $item->id) . '">
                    <i class="fas fa-edit"></i> &nbsp; Ubah
                    </a>
                    ';
                }

                if($item->status=='pending' ||$item->status=='Request Update'){
                    $buttons .= '<form action="' . route('letter.destroy', $item->id) . '" method="POST" onsubmit="return confirm(' . "'Anda akan menghapus item ini?'" . ')">
                    ' . method_field('delete') . csrf_field() . '
                    <button class="btn btn-danger btn-xs">
                    <i class="far fa-trash-alt"></i> &nbsp; Hapus
                    </button>
                    </form>';
                }
            }

            if (auth()->user()->level == 'manajer') {
                $buttons .= '<form action="' . route('letter.destroy', $item->id) . '" method="POST" onsubmit="return confirm(' . "'Anda akan menghapus item ini?'" . ')">
                ' . method_field('delete') . csrf_field() . '
                <button class="btn btn-danger btn-xs">
                <i class="far fa-trash-alt"></i> &nbsp; Hapus
                </button>
                </form>';
            }

            if (auth()->user()->level == 'manajer') {
                if($item->status=='pending'){
                    $buttons .= '
                    <form action="' . route('approval', $item->id) . '" method="POST" onsubmit="return confirm(' . "'Anda akan approve item ini?'" . ')">
                    ' . method_field('post') . csrf_field() . '
                    <input name="status" value="Approve"/ hidden>
                    <button class="btn btn-success btn-xs">
                    <i class="fas fa-check"></i> &nbsp; Approve
                    </button>
                    </form>
                    <form action="' . route('approval', $item->id) . '" method="POST" onsubmit="return submitFormReq()">
                    ' . method_field('post') . csrf_field() . '
                    <input name="status" value="Request Update" hidden>
                    <input id="commentInput" name="komentar" value="" hidden>
                    <button class="btn btn-warning btn-xs">
                    <i class="fas fa-exclamation"></i> &nbsp; Request
                    </button>
                    </form>
                    <script>
                    function submitFormReq() {
                        var comment = prompt("Anda akan request perubahan?");
                        if (comment === null) {
                            return false;
                        }

                        document.getElementById("commentInput").value = comment;
                        return true;
                    }
                    </script>
                    </form>
                    <form action="' . route('approval', $item->id) . '" method="POST" onsubmit="return submitForm()">
                    ' . method_field('post') . csrf_field() . '
                    <input name="status" value="Not Approve" hidden>
                    <input id="commentInputNot" name="komentar" value="" hidden>
                    <button class="btn btn-danger btn-xs">
                    <i class="fas fa-exclamation"></i> &nbsp; Not Approve
                    </button>
                    </form>
                    <script>
                    function submitForm() {
                        var comment = prompt("Anda akan Not Approve?");
                        if (comment === null) {
                            return false;
                        }

                        document.getElementById("commentInputNot").value = comment;
                        return true;
                    }
                    </script>
                    </form>';
                }
            }

            return $buttons;
        })
->editColumn('post_status', function ($item) {
    return $item->post_status == 'Published' ? '<div class="badge bg-green-soft text-green">' . $item->post_status . '</div>' : '<div class="badge bg-gray-200 text-dark">' . $item->post_status . '</div>';
})
->addIndexColumn()
->removeColumn('id')
->rawColumns(['action', 'post_status'])
->make();
}

return view('pages.admin.letter.outgoing');
}

public function show($id)
{
    $item = Letter::with(['department','sender','receiver'])->findOrFail($id);

    return view('pages.admin.letter.show',[
        'item' => $item,
    ]);
}

public function edit($id)
{
    $item = Letter::findOrFail($id);

    $departments = Department::all();
    $senders = Sender::all();

    return view('pages.admin.letter.edit',[
        'departments' => $departments,
        'senders' => $senders,
        'item' => $item,
    ]);
}

public function download_letter($id)
{
    $item = Letter::findOrFail($id);

    return Storage::download($item->letter_file);
}

public function update(Request $request, $id)
{
    $validatedData = $request->validate([
        'letter_no' => 'required',
        'letter_date' => 'required',
        'date_received' => 'required',
        'regarding' => 'required',
        'department_id' => 'required',
        'sender_id' => 'required',
        'letter_file' => 'mimes:pdf|file',
        'letter_type' => 'required',
    ]);

    $item = Letter::findOrFail($id);

    if($request->file('letter_file')){
        $validatedData['letter_file'] = $request->file('letter_file')->store('assets/letter-file');
    }

    $type='Surat Masuk';
    if ($validatedData['letter_type'] == 'Surat Masuk') {
        $redirect = 'surat-masuk';
    } else {
        $redirect = 'surat-keluar';
        $type='Surat Keluar';
    }

    $validatedData['status']='pending';

    $item->update($validatedData);

    $letter=Letter::findOrFail($id);
    Notification::create([
        'keterangan'=>'Update '.$type.'<br>Kode :'.$letter->letter_no.'<br> Keterangan: Surat telah di update oleh '.auth()->user()->name,
        'id_surat'=>$letter->id,
        'level'=>'manajer'
    ]);
    return redirect()
    ->route($redirect)
    ->with('success', 'Sukses! 1 Data Berhasil Diubah');
}

public function destroy($id)
{
    $item = Letter::findorFail($id);

    if ($item->letter_type == 'Surat Masuk') {
        $redirect = 'surat-masuk';
    } else {
        $redirect = 'surat-keluar';
    }

    Storage::delete($item->letter_file);

    $item->delete();

    return redirect()
    ->route($redirect)
    ->with('success', 'Sukses! 1 Data Berhasil Dihapus');
}
}
