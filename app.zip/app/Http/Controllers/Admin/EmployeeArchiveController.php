<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\Models\EmployeeArchive;
use App\Models\Employee;
use App\Models\Category;
use App\Models\Department;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;
use App\Models\Notification;
class EmployeeArchiveController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
        $a= EmployeeArchive::with('employee','department')->get();
        foreach ($a as $key => $value) {
          $date_end = explode(' sampai ', $value->retensi_arsip)[1];
          $date_end = \Carbon\Carbon::parse($date_end); 


          $days_until_expiry = now()->diffInDays($date_end, false);


          $existingNotification = Notification::whereDate('created_at', now()->toDateString())
          ->where('id_surat', $value->id)
          ->where('level', 'karyawan')
          ->exists();

          if ($days_until_expiry < 30 && !$existingNotification) {
            Notification::create([
                'keterangan' => 'Masa berlaku arsip karyawan sebentar lagi habis<br>Kode :' . $value->kode_arsip_karyawan,
                'id_surat' => $value->id,
                'tipe_arsip'=>'karyawan',
                'level' => 'karyawan'
            ]);
        }
    }
    if (request()->ajax()) {
        $query = EmployeeArchive::with('employee','department')->latest()->get();

        return Datatables::of($query)
        ->addColumn('action', function ($item) {
            return '
            <a class="btn btn-success btn-xs" href="' . route('employee-archive.show', $item->id) . '">
            <i class="fa fa-search-plus"></i> &nbsp; Detail
            </a>
            <a class="btn btn-primary btn-xs" href="' . route('employee-archive.edit', $item->id) . '">
            <i class="fas fa-edit"></i> &nbsp; Ubah
            </a>
            <form action="' . route('employee-archive.destroy', $item->id) . '" method="POST" onsubmit="return confirm('."'Anda akan menghapus item ini dari situs anda?'".')">
            ' . method_field('delete') . csrf_field() . '
            <button type="submit" class="btn btn-danger btn-xs">
            <i class="far fa-trash-alt"></i> &nbsp; Hapus
            </button>
            </form>
            ';
        })
        ->editColumn('post_status', function ($item) {
            return $item->post_status == 'Published' ? '<div class="badge bg-green-soft text-green">'.$item->post_status.'</div>' : '<div class="badge bg-gray-200 text-dark">'.$item->post_status.'</div>';
        })
        ->addIndexColumn()
        ->removeColumn('id')
        ->rawColumns(['action', 'post_status'])
        ->make();
    }

    return view('pages.admin.employee-archive.index');
}


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $departments = Department::all();
        $employee = Employee::all();
        $categories = Category::all();

        return view('pages.admin.employee-archive.create',[
            'departments' => $departments,
            'employees' => $employee,
            'categories' => $categories,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    { 
       $request->merge(['retensi_arsip' => $request->from . ' sampai ' . $request->to]);
       $validatedData = $request->validate([
        'kode_arsip_karyawan' => 'required|unique:arsip_karyawan,kode_arsip_karyawan',
        'id_kategori_arsip' => 'required',
        'id_karyawan' => 'required',
        'department_id' => 'required',
        'retensi_arsip' => 'required',
        'file_arsip_karyawan' => 'required|mimes:pdf|file',
    ]);

       if($request->file('file_arsip_karyawan')){
        $validatedData['file_arsip_karyawan'] = $request->file('file_arsip_karyawan')->store('assets/file-arsip-karyawan');
    }


    EmployeeArchive::create($validatedData);

    return redirect()
    ->route('employee-archive.index')
    ->with('success', 'Sukses! 1 Data Berhasil Disimpan');
}

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $item = EmployeeArchive::with('department','employee','category')->findOrFail($id);

        return view('pages.admin.employee-archive.show',[
            'item' => $item,
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $departments = Department::all();
        $categories = Category::all();
        $item = EmployeeArchive::findOrFail($id);
        $employee = Employee::all();

        return view('pages.admin.employee-archive.edit',[
            'departments' => $departments,
            'employees' => $employee,
            'categories' => $categories,
            'item'=>$item
        ]);
    }

    public function download_archive($id)
    {
        $item = EmployeeArchive::findOrFail($id);

        return Storage::download($item->file_arsip_karyawan);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $validatedData = $request->validate([
            'kode_arsip_karyawan' => 'required',
            'id_kategori_arsip' => 'required',
            'id_karyawan' => 'required',
            'department_id' => 'required',
            'retensi_arsip' => 'required',
        ]);

        $item = EmployeeArchive::findOrFail($id);

        if ($request->file('file_arsip_karyawan')) {
            $validatedData['file_arsip_karyawan'] = $request->file('file_arsip_karyawan')->store('assets/file-arsip-karyawan');
        }

        $item->update($validatedData);

        return redirect()
        ->route('employee-archive.index')
        ->with('success', 'Sukses! 1 Data Berhasil Diubah');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
