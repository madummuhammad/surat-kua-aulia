<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\Models\Documentation;
use App\Models\Department;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\Storage;
class DocumentationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (request()->ajax()) {
            $query = Documentation::with('department')->latest()->get();

            return Datatables::of($query)
            ->addColumn('action', function ($item) {
                return '
                <a class="btn btn-success btn-xs" href="' . route('documentation.show', $item->id) . '">
                <i class="fa fa-search-plus"></i> &nbsp; Detail
                </a>
                <a class="btn btn-primary btn-xs" href="' . route('documentation.edit', $item->id) . '">
                <i class="fas fa-edit"></i> &nbsp; Ubah
                </a>
                <form action="' . route('documentation.destroy', $item->id) . '" method="POST" onsubmit="return confirm('."'Anda akan menghapus item ini dari situs anda?'".')">
                ' . method_field('delete') . csrf_field() . '
                <button type="submit" class="btn btn-danger btn-xs">
                <i class="far fa-trash-alt"></i> &nbsp; Hapus
                </button>
                </form>
                ';
            })
            ->editColumn('post_status', function ($item) {
                return $item->post_status == 'Published' ? '<div class="badge bg-green-soft text-green">'.$item->post_status.'</div>' : '<div class="badge bg-gray-200 text-dark">'.$item->post_status.'</div>';
            })
            ->addIndexColumn()
            ->removeColumn('id')
            ->rawColumns(['action', 'post_status'])
            ->make();
        }

        return view('pages.admin.documentation.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $departments = Department::all();

        return view('pages.admin.documentation.create',[
            'departments' => $departments,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'kode_arsip_dokumentasi' => 'required|unique:arsip_dokumentasi,kode_arsip_dokumentasi',
            'department_id' => 'required',
            'id_karyawan' => 'required',
            'tanggal_dokumentasi' => 'required',
            'keterangan' => 'required',
            'file_arsip_dokumentasi' => 'required|mimes:jpg,png|file',
        ]);

        if($request->file('file_arsip_dokumentasi')){
            $validatedData['file_arsip_dokumentasi'] = $request->file('file_arsip_dokumentasi')->store('assets/file-arsip-dokumentasi');
        }


        Documentation::create($validatedData);

        return redirect()
        ->route('documentation.index')
        ->with('success', 'Sukses! 1 Data Berhasil Disimpan');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $item = Documentation::with('department')->findOrFail($id);

        return view('pages.admin.documentation.show',[
            'item' => $item,
        ]);
    }

    public function download_archive($id)
    {
        $item = Documentation::findOrFail($id);

        return Storage::download($item->file_arsip_dokumentasi);
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $item = Documentation::findOrFail($id);

        $departments = Department::all();

        return view('pages.admin.documentation.edit',[
            'departments' => $departments,
            'item'=>$item
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->merge(['id_karyawan' => auth()->user()->id]);

        $validatedData = $request->validate([
            'kode_arsip_dokumentasi' => 'required',
            'department_id' => 'required',
            'id_karyawan' => 'required',
            'tanggal_dokumentasi' => 'required',
            'keterangan' => 'required'
        ]);

        $item = Documentation::findOrFail($id);

        if ($request->file('file_arsip_dokumentasi')) {
            $validatedData['file_arsip_dokumentasi'] = $request->file('file_arsip_dokumentasi')->store('assets/file-arsip-dokumentasi');
        }

        $item->update($validatedData);

        return redirect()
        ->route('documentation.index')
        ->with('success', 'Sukses! 1 Data Berhasil Diubah');
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $item = Documentation::findorFail($id);

        $item->delete();

        return redirect()
        ->route('documentation.index')
        ->with('success', 'Sukses! 1 Data Berhasil Dihapus');
    }
}
