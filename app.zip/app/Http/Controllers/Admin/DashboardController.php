<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Letter;
use App\Models\EmployeeArchive;
use App\Models\Documentation;
use App\Models\Employee;
use App\Models\Sender;
use App\Models\Category;
use App\Models\PenerimaSurat;
use App\Models\Department;

class DashboardController extends Controller
{
    public function index()
    {
        $masuk = Letter::where('letter_type', 'Surat Masuk')->get()->count();
        $keluar = Letter::where('letter_type', 'Surat Keluar')->get()->count();
        $arsip_karyawan=EmployeeArchive::get()->count();
        $documentation=Documentation::get()->count();
        $karyawan=Employee::get()->count();
        $receiver=PenerimaSurat::get()->count();
        $category=Category::get()->count();
        $sender=Sender::get()->count();
        $department=Department::get()->count();

        return view('pages.admin.dashboard',[
            'masuk' => $masuk,
            'keluar' => $keluar,
            'arsip_karyawan' => $arsip_karyawan,
            'documentation' => $documentation,
            'karyawan' => $karyawan,
            'receiver' => $receiver,
            'category' => $category,
            'department' => $department,
            'sender' => $sender
        ]);
    }
}
